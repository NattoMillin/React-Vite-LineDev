/// <reference types="vite/client" />
interface ImportMetaEnv {
    VITE_APP_LIFF_ID: string;
}