
export const Loading=()=> {
    return <h2>Loading...</h2>;
}