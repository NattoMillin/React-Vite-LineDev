export declare const RtnMsg: () => Promise<void>;
export declare const getUserInfo: () => Promise<void>;
