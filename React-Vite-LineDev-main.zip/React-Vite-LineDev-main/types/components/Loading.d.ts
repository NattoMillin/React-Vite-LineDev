export declare const Loading: () => import("react/jsx-runtime").JSX.Element;
