export type FormValues = {
    FirstName: string;
    SelectItem: string;
};
declare function Home(): import("react/jsx-runtime").JSX.Element;
export default Home;
