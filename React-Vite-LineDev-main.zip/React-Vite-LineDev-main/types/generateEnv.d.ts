export declare const generateEnv: () => {
    liffId: string;
    mock: boolean;
};
